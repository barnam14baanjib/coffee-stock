import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, transactionsTable, insertTransactionSchema } from "@workspace/db";

const router: IRouter = Router();

router.get("/transactions", async (_req, res): Promise<void> => {
  const transactions = await db
    .select()
    .from(transactionsTable)
    .orderBy(transactionsTable.createdAt);
  res.json(transactions);
});

router.post("/transactions", async (req, res): Promise<void> => {
  const parsed = insertTransactionSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [transaction] = await db.insert(transactionsTable).values(parsed.data).returning();
  res.status(201).json(transaction);
});

router.delete("/transactions/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const [transaction] = await db.delete(transactionsTable).where(eq(transactionsTable.id, id)).returning();
  if (!transaction) { res.status(404).json({ error: "Transaction not found" }); return; }
  res.sendStatus(204);
});

export default router;
